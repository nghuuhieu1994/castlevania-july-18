﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToolTileMap
{
    public partial class Form1 : Form
    {
        #region CONST
        int Tile_Height = 32;
        int Tile_Width = 32;
        List<Bitmap> ListBitmap;
        #endregion
        
        int[,] Matrix;
        public Form1()
        {
            InitializeComponent();
            this.pnSourcePic.AutoScroll = true;
            this.pbSourcePic.SizeMode = PictureBoxSizeMode.AutoSize;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.panel1.AutoScroll = true;
            this.pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            string _filePath = "..\\resources\\default.png";
            this.pbSourcePic.Image = new Bitmap(_filePath);
        }

        private void pbSourcePic_Click(object sender, EventArgs e)
        {
            OpenFileDialog _open = new OpenFileDialog();
            _open.ShowDialog();
            if (_open.FileName != "")
            {
                pbSourcePic.Image = new Bitmap(_open.FileName);
                Benchmark.Start();
                CreateTiles();
                SortListBitMap();
                GetTileMatrix();
                Benchmark.End();
                MessageBox.Show(Benchmark.GetSeconds().ToString());
            }
        }

        private bool CompareBitMap(Bitmap _bm1, Bitmap _bm2)
        {
            for (int _count_height = 0; _count_height < Tile_Height; _count_height++)
            {
                for (int _count_width = 0; _count_width < Tile_Width; _count_width++)
                {
                    if (_bm1.GetPixel(_count_width, _count_height) != (_bm2.GetPixel(_count_width, _count_height)))
                    {
                        return false;
                    }
                }   
            }
            return true;
        }

        private void ReplaceMatrix(int _value, int _key)
        {
            int Array_Width = pbSourcePic.Image.Width / Tile_Width;
            int Array_Height = pbSourcePic.Image.Height / Tile_Height;

            for (int i = 0; i < Array_Height; ++i)
            {
                for (int j = 0; j < Array_Width; ++j)
                {
                    if (Matrix[i, j] == _key)
                    {
                        Matrix[i, j] = _value;
                    }
                }
            }
        }

        private void SortListBitMap()
        {
            int Array_Width = pbSourcePic.Image.Width / Tile_Width;
            int Array_Height = pbSourcePic.Image.Height / Tile_Height;
            List<Bitmap> currentList = new List<Bitmap>();

            for (int i = 0; i < ListBitmap.Count; i++)
            {
                bool isExist = false;
                for (int j = 0; j < currentList.Count; j++)
                {
                    if (CompareBitMap(ListBitmap[i], currentList[j]))
                    {
                        isExist = true;
                        Matrix[i / Array_Width, i % Array_Width] = j;
                        break;
                    }
                }
                if (!isExist)
                {
                    Matrix[i / Array_Width, i % Array_Width] = currentList.Count;
                    currentList.Add(ListBitmap[i]);
                }
            }

            Image img = new Bitmap(currentList.Count * 32, 32);
            for (int i = 0; i < currentList.Count; i++)
            {
                Graphics g = Graphics.FromImage(img);
                g.DrawImage(currentList[i], new Point(i * 32, 0));
                currentList[i].Save("..\\textures\\" + i.ToString() + ".png");
            }
            pictureBox1.Image = img;
            img.Save("..\\textures\\tiled.png");
        }

        private void GetTileMatrix()
        {
            int Array_Width = pbSourcePic.Image.Width / Tile_Width;
            int Array_Height = pbSourcePic.Image.Height / Tile_Height;

            StreamWriter _writeFile = new StreamWriter("map.txt");

            for (int i = 0; i < Array_Height; ++i)
            {
                for (int j = 0; j < Array_Width; ++j)
                {
                    _writeFile.Write(Matrix[i, j] + " ");
                }

                _writeFile.WriteLine();
            }

            _writeFile.Close();
        }

        private void CreateTiles()
        {
            int Array_Width = pbSourcePic.Image.Width / Tile_Width;
            int Array_Height = pbSourcePic.Image.Height / Tile_Height;
            Bitmap main = pbSourcePic.Image as Bitmap;
            ListBitmap = new List<Bitmap>();
            Matrix = new int[Array_Height, Array_Width];
            for (int _count_height = 0; _count_height < Array_Height; _count_height++)
            {
                for (int _count_width = 0; _count_width < Array_Width; _count_width++)
                {
                    Bitmap current = CropBitmap(main, _count_width * Tile_Width, _count_height * Tile_Height, Tile_Width, Tile_Height);
                    Matrix[_count_height, _count_width] = ListBitmap.Count;
                    ListBitmap.Add(current);
                }
            }
        }

        private  Bitmap CropBitmap(Bitmap bitmap, int cropX, int cropY, int cropWidth, int cropHeight)
        {
            Rectangle rect = new Rectangle(cropX, cropY, cropWidth, cropHeight);
            Bitmap cropped = bitmap.Clone(rect, bitmap.PixelFormat);
            return cropped;
        }
    }
    public class Benchmark
    {
        private static DateTime startDate = DateTime.MinValue;
        private static DateTime endDate = DateTime.MinValue;

        public static TimeSpan Span { get { return endDate.Subtract(startDate); } }

        public static void Start() { startDate = DateTime.Now; }

        public static void End() { endDate = DateTime.Now; }

        public static double GetSeconds()
        {
            if (endDate == DateTime.MinValue) return 0.0;
            else return Span.TotalSeconds;
        }
    }

}
